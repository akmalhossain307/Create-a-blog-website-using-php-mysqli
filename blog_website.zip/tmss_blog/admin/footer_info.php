 
<?php include("inc/header.php");?>
<?php include("inc/sidebar.php");?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    

    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      <div class="row">
        
      </div>
      <!-- /.row -->
      <!-- Main row -->
	 <div class="col-md-1"></div>
	 <div class="col-md-10">
	 <h1> Change website's Footer Info</h1><br />
		<?php 
	 if(isset($_POST['submit']))
	 {
		$copyright		=$_POST['copyright']; 
		;
		if($copyright=="")
		{
			echo"<script>alert('Plz enter a copyright text to change!')</script>";
			echo"<script>window.location='footer_info.php'</script>";
			
			
		}
		else 
		{
			
			$u_query=mysqli_query($con,"UPDATE blog_footer SET 
			copyright='$copyright'
			WHERE id=1");
			if($u_query)
			{
				echo"<script>alert('Copyright text Updated Successfully!')</script>";
				echo"<script>window.location='footer_info.php'</script>";
			}
			else
			{
				echo"<script>alert('Copyright text not Updated!')</script>";
				echo"<script>window.location='footer_info.php'</script>";
			}
		}
		 
	 }
	 ?>
	 
	 
		<form action=""method="post"enctype="multipart/form-data">
		<?php 
		$c_query=mysqli_query($con,"SELECT * FROM blog_footer");
		while($info=mysqli_fetch_array($c_query))
		{
			?>
		<div class="row"> 
		<div class="col-md-5">
			<div class="form-group">
			<label for="first_name">Copyright Text</label>
			<input type="text" class="form-control" name="copyright">
			</div>
			<button type="submit" name="submit"class="btn btn-success">Change Info</button>
		</div>
		<div class="col-md-5">
		<h2>Copyright Text:</h2> <p><?php echo$info['copyright'];?></p>
		
		</div>
	
		</div>	
		</form>
	  </div>
	  <div class="col-md-1"></div>
	  	
			<?php 
		}
		?>
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	
      <!-- /.row (main row) -->

    </section>
    <!-- /.content -->
  </div>
  
  
  <?php 
  include("inc/footer.php");
  ?>