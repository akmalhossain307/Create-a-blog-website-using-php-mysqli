 
<?php include("inc/header.php");?>
<?php include("inc/sidebar.php");?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    

    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      <div class="row">
        
      </div>
      <!-- /.row -->
      <!-- Main row -->
	 
	 <div class="col-md-12">
	
<div class="row"> 
	<div class="col-md-2"></div>
		<div class="col-md-8">
	 <h1> Category List</h1><br />
	<div class="box">
            <div class="box-header">
             
            </div>
            <!-- /.box-header -->
			<?php
			if(isset($_GET['del']))
			{
			$delID=$_GET['del'];
			$q=mysqli_query($con,"DELETE FROM blog_category WHERE id=$delID");
			if($q)
			{
				//echo"<h2 id='success'>Category deleted Successfully!</h2>";
				echo"<script>window.location='catlist.php';</script>";
			}
			else
			{
			echo"<script>alert('<h2 id='danger'>Category not deleted!</h2>');</script>";	
			}
			}			
			?>
			
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead align="center">
                <tr >
                  <th width="5%" style="font-size:18px;color:green">SL No.</th>
                  <th width="50%"style="font-size:18px;color:green">Title</th>
                  <th width="45%"style="font-size:18px;color:green">Action</th>
                </tr>
                </thead>
                <tbody>
				<?php 
				$i=0;
				$q=mysqli_query($con,"SELECT * FROM blog_category");
				while($result=mysqli_fetch_array($q))
				{
				$i++;
				?>
                <tr align="center">
                  <td><?php echo$i;?></td>
                  <td><?php echo$result['cat_name'];?>
                  </td>
                  <td><a class="btn btn-info"href="editcat.php?edit=<?php echo$result['id'];?>">Edit</a> <a onclick="return confirm('Are you sure to delete this category?');"class="btn btn-danger"href="?del=<?php echo$result['id'];?>"> Delete</a></td>
                  
                </tr>
				<?php 
				}
				?>
                </tbody>
               
              </table>
            </div>
            <!-- /.box-body -->
          </div>
	
	
		</div>
	<div class="col-md-2"></div>
</div>
		 
		  
		  
		
		
		
		
	  </div>
	 
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	
      <!-- /.row (main row) -->

    </section>
    <!-- /.content -->
  </div>
  
  
  <?php 
  include("inc/footer.php");
  ?>