 
<?php include("inc/header.php");?>
<?php include("inc/sidebar.php");?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    

    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      <div class="row">
        
      
      <!-- /.row -->
      <!-- Main row -->
	
	<div class="row"> 
	<div class="col-md-3"></div>
	<div class="col-md-8"><h1>Add New Post</h1>
	<?php 
	if(isset($_POST['submit']))
	{
			function test_input($data)
			{
				$data=trim($data);
				$data=addslashes($data);
				$data=htmlspecialchars($data);
				return $data;
			}
			$title			=test_input($_POST['title']);
			$title			=filter_var($_POST['title'],FILTER_SANITIZE_STRING);
			$author			=test_input($_POST['author']);
			$author			=filter_var($_POST['author'],FILTER_SANITIZE_STRING);
			$tags			=test_input($_POST['tags']);
			$tags			=filter_var($_POST['tags'],FILTER_SANITIZE_STRING);
			$category		=test_input($_POST['category']);
			$category		=filter_var($_POST['category'],FILTER_SANITIZE_STRING);
			$content		=test_input($_POST['content']);
			$content		=filter_var($_POST['content'],FILTER_SANITIZE_STRING);
			$image_name		=$_FILES['image']['name'];
			$image_size		=$_FILES['image']['size'];
			$temp_image		=$_FILES['image']['tmp_name'];
			$div			=explode('.',$image_name);
			$f_ext			=strtolower(end($div));
			$uni_file		=substr(md5(time()),0,10).'.'.$f_ext;
			$uploaded_file	="upload/".$uni_file;
			if($title=="" || $author=="" || $tags=="" || $category=="" || $content=="")
			{
			echo"<h2 id='danger'>All fields must be filled out!</h2>";	
			}
			else
			{
			if($image_name=="")	
			{
				$q=mysqli_query($con,"INSERT INTO blog_post (title,category,author,content,tags) VALUES ('$title','$category','$author','$content','$tags')");
				if($q)
				{
					echo"<h2 id='success'>Post Inserted without image Successfully!</h2>";
				}
				else
				{
					echo"<h2 id='danger'>Post not Inserted</h2>";
				}
			}
			else 
			{
				move_uploaded_file($temp_image,$uploaded_file);
				$q=mysqli_query($con,"INSERT INTO blog_post (title,category,author,image,content,tags) VALUES ('$title','$category','$author','$uni_file','$content','$tags')");
				if($q)
				{
					echo"<h2 id='success'>Post Inserted with image Successfully!</h2>";
				}
				else
				{
					echo"<h2 id='danger'>Post not Inserted</h2>";
				}
			}
			
			}
			
	}
	?>
	
	
	
			</div>
			<div class="col-md-1"></div>
	</div>
	<br />
	
	
	 <div class="col-md-12">
	 
		<form action="" method="post" enctype="multipart/form-data">
		<div class="row">
			
		<div class="col-md-1"></div>		
		<div class="col-md-5">
		
			<div class="form-group">
			<label for="first_name">Post title</label>
			<input type="text" class="form-control" id="title" name="title">
			</div>
			<div class="form-group">
			<label for="author_name">Post Author</label>
			<input type="text" class="form-control" id="author" name="author">
			</div>
			<div class="form-group">
			<label for="first_name">Post tags</label>
			<input type="text" class="form-control" id="title" name="tags">
			</div>
		
		</div>
		<div class="col-md-5">
			<div class="form-group">
			<label for="author_name">Post Image</label>
			<input type="file" class="form-control" id="author" name="image">
			</div>
			<div class="form-group">
			  <label for="sel1">Post Category</label>
			  <select class="form-control" id="sel1" name="category">
			  <?php 
			  $query=mysqli_query($con,"SELECT * FROM blog_category");
			  while($re=mysqli_fetch_array($query))
			  {
				?>
				<option value="<?php echo$re['cat_name'];?>"><?php echo$re['cat_name'];?></option>
			<?php 
			
			  }
			  ?>
			  </select>
			</div>
		
		</div>
		<div class="col-md-1"></div>
		</div>
			
			
			
			
			
			
	<div class="row"> 
		<div class="col-md-1"></div>
		<div class="col-md-10">
			<label for="post content">Post Content</label>
			<textarea id="editor1" name="content"></textarea>
		</div>
		<div class="col-md-1"></div>
	</div><br />	
	<div class="row"> 
		<div class="col-md-4"></div>
		<div class="col-md-4">
			<button type="submit" name="submit"class="btn btn-success">Add Post</button>
		</div>
		<div class="col-md-4"></div>
	</div>	
			
		</form>
	  </div>
	  
	  </div>
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	
      <!-- /.row (main row) -->

    </section>
    <!-- /.content -->
  </div>
  
  
  <?php 
  include("inc/footer.php");
  ?>