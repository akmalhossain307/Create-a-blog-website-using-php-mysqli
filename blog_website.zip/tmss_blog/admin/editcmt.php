 
<?php include("inc/header.php");?>
<?php include("inc/sidebar.php");?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    

    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      <div class="row">
        
      </div>
      <!-- /.row -->
      <!-- Main row -->
	 <div class="col-md-3"></div>
	 <div class="col-md-6">
	 <h1> Edit Category</h1><br />
	<?php
		if(isset($_GET['edit']))
		{
			$editID=$_GET['edit'];
			$q=mysqli_query($con,"SELECT * FROM blog_comments WHERE id=$editID");
			while($result=mysqli_fetch_array($q))
			{
				
				?>
				
			
		<form action="" method="post">
			<div class="form-group">
			<label for="catname">Comment</label>
			<input type="text" class="form-control" id="cat_name" name="comment" value="<?php echo$result['comment'];?>">
			</div>
			<button type="submit" name="submit"class="btn btn-success">Update Comment</button>
			<a href="user_comments.php" class="btn btn-primary"> Back</a>
		</form>
		
		
		<?php 
		}
		
		?>
		<?php 
		if(isset($_POST['submit']))
		{
			// Function for filtering input values.
			function test_input($data)
			{
			$data = trim($data);//Removes whitespaces from both sides
			$data = addslashes($data);// Add backslashes to the predefined characters in a string
			$data = htmlspecialchars($data);//The htmlspecialchars() function converts some predefined characters to HTML entities.
			$data = filter_var($data,FILTER_SANITIZE_STRING);
			return $data;
			}
			
			
			$cmt=test_input($_POST['comment']);
			//$cat_name=filter_var($_POST['cat_name'], );//sanitizes the input using filter
	
		if($cmt=="" || $cmt==null)
		{
			echo"<h2 id='danger'>Comment field is empty</h2>";
		}
		else
		{
			
		$cmt_query=mysqli_query($con,"UPDATE blog_comments 
		SET
		comment='$cmt'
		WHERE
		id=$editID
		");
		
			if($cmt_query)
			{
			//echo"<h2 id='success'>Category $cat_name updated Successfully!</h2>";
			echo"<script>alert('<h2 id='success'>Comment updated Successfully!</h2>');</script>";
			echo"<script>window.location='user_comments.php';</script>";
			//header("location:catlist.php");
			}
			else
			{
					//echo"<h2 id='danger'>Comment not updated!</h2>";
			echo"<script>alert('<h2 id='danger'>Comment not updated!</h2>');</script>";
			echo"<script>window.location='user_comments.php';</script>";
			}	
		}
		
			
		
		}
		}
		?>
		
	  </div>
	  <div class="col-md-3"></div>
	  

	
      <!-- /.row (main row) -->

    </section>
    <!-- /.content -->
  </div>
  
  
  <?php 
  include("inc/footer.php");
  ?>