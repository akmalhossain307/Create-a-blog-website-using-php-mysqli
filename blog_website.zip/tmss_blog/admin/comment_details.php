 
<?php include("inc/header.php");?>
<?php include("inc/sidebar.php");?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    

    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      <div class="row">
        
      </div>
      <!-- /.row -->
      <!-- Main row -->
	 <div class="col-md-3"></div>
	 <div class="col-md-6">
	 <h1> Blog User Comment Details</h1><br />
	<?php
		if(isset($_GET['cmt_details']))
		{
			$detailsID=$_GET['cmt_details'];
			$q=mysqli_query($con,"SELECT * FROM blog_comments WHERE id=$detailsID");
			while($result=mysqli_fetch_array($q))
			{
				
				?>
				
			
		
			<div class="form-group">
			
			<label for="catname">User</label>
			<input type="text" class="form-control" value="<?php echo$result['user'];?>" readonly /> <br />
			<label for="catname">Date</label>
			<input type="text" class="form-control" value="<?php echo date('d-m-Y',strtotime($result['date']));?>" readonly /> <br />
			<label for="catname">Comment</label>
			<textarea name="" class="form-control" id="" cols="30" rows="10" readonly> <?php echo$result['comment'];?></textarea>
			
			</div>
			<a href="user_comments.php" class="btn btn-primary">Ok</a>
		
		
		
		<?php 
		}
		}
		?>
		
		
	  </div>
	  <div class="col-md-3"></div>
	  
	  
	  
      <!-- /.row (main row) -->

    </section>
    <!-- /.content -->
  </div>
  
  
  <?php 
  include("inc/footer.php");
  ?>