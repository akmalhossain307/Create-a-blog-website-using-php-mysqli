 
<?php include("inc/header.php");?>
<?php include("inc/sidebar.php");?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    

    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      <div class="row">
        
      </div>
      <!-- /.row -->
      <!-- Main row -->
	 <div class="col-md-3"></div>
	 <div class="col-md-6">
	 <h1> Update Category</h1><br />
	<?php
		if(isset($_GET['edit']))
		{
			$editID=$_GET['edit'];
			$q=mysqli_query($con,"SELECT * FROM blog_category WHERE id=$editID");
			while($result=mysqli_fetch_array($q))
			{
				
				?>
				
			
		<form action="" method="post">
			<div class="form-group">
			<label for="catname">Category Name</label>
			<input type="text" class="form-control" id="cat_name" name="cat_name" value="<?php echo$result['cat_name'];?>">
			</div>
			<button type="submit" name="submit"class="btn btn-success">Update Category</button>
		</form>
		
		
		<?php 
		}
		}
		?>
		<?php 
		if(isset($_POST['submit']))
		{
			// Function for filtering input values.
			function test_input($data)
			{
			$data = trim($data);//Removes whitespaces from both sides
			$data = addslashes($data);// Add backslashes to the predefined characters in a string
			$data = htmlspecialchars($data);//The htmlspecialchars() function converts some predefined characters to HTML entities.
			return $data;
			}
			
			
			$cat_name=test_input($_POST['cat_name']);
			$cat_name=filter_var($_POST['cat_name'], FILTER_SANITIZE_STRING);//sanitizes the input using filter
	
		if($cat_name=="" || $cat_name==null)
		{
			echo"<h2 id='danger'>Plz Give a category Name</h2>";
		}
		else
		{
			
		$query=mysqli_query($con,"UPDATE blog_category 
		SET
		cat_name='$cat_name'
		WHERE
		id=$editID
		");
		
			if($query)
			{
			//echo"<h2 id='success'>Category $cat_name updated Successfully!</h2>";
			echo"<script>alert('<h2 id='success'>Category $cat_name updated Successfully!</h2>');</script>";
			echo"<script>window.location='catlist.php';</script>";
			//header("location:catlist.php");
			}
			else
			{
					echo"<h2 id='danger'>Category $cat_name not updated!</h2>";
			}	
		}
		
			
		
		}
		?>
		
	  </div>
	  <div class="col-md-3"></div>
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	
      <!-- /.row (main row) -->

    </section>
    <!-- /.content -->
  </div>
  
  
  <?php 
  include("inc/footer.php");
  ?>