<?php 
$str="<h2>akmal";
$str1 = filter_var($str, FILTER_SANITIZE_STRING);
echo$str1;
?>