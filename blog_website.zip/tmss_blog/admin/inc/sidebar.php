<!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="dist/img/admin.jpg" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p>Akmal Hossain</p>
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>
     
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu">
       
        
        <li class="treeview">
          <a href="#">
           
            <span>Header & Footer Options</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="title.php"><i class="fa fa-circle-o"></i> Title & Icon </a></li>
            <li><a href="logo_banner.php"><i class="fa fa-circle-o"></i> Logo & Banner</a></li>
            
            <li><a href="footer_info.php"><i class="fa fa-circle-o"></i> Footer Info</a></li>
          </ul>
        </li> 
		 
		<li class="treeview">
          <a href="#">
           
            <span>Category Options</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="addcat.php"><i class="fa fa-circle-o"></i> Add New Category</a></li>
            <li><a href="catlist.php"><i class="fa fa-circle-o"></i> Category List</a></li>
          
          </ul>
        </li>
		<li class="treeview">
          <a href="#">
            
            <span>Post Options</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="addpost.php"><i class="fa fa-circle-o"></i>Add new Post</a></li>
            <li class="active"><a href="postlist.php"><i class="fa fa-circle-o"></i> Post List</a></li>
           
          </ul>
        </li>
		<li class="treeview">
          <a href="#">
            
            <span>User & Subscriber Options</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="subscriber.php"><i class="fa fa-circle-o"></i>subscribers Option</a></li>
            <li class="active"><a href="user.php"><i class="fa fa-circle-o"></i>Blog Users</a></li>
           
          </ul>
        </li> 
		
		<li class="treeview">
          <a href="#">
            
            <span>Comment Options</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="user_comments.php"><i class="fa fa-circle-o"></i>Comments</a></li>
            
           
          </ul>
        </li> 
		<li class="treeview">
          <a href="#">
            
            <span>Contact Options</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="viewmsg.php"><i class="fa fa-circle-o"></i>Contact</a></li>
            
           
          </ul>
        </li> 
       
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>