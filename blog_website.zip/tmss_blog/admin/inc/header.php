<?php 
session_start();
$con=mysqli_connect("localhost","root","","bddevste_my_blog");
if(!isset($_SESSION['username']))
{
	header("location: admin_log.php");
}
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Admin | Dashboard</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.6 -->
  <link rel="stylesheet" href="bootstrap/bootstrap.min.css">
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  
  
  <!-- DataTables -->
  <link rel="stylesheet" href="bootstrap/dataTables.bootstrap.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="plugins/iCheck/flat/blue.css">
  <!-- Morris chart -->
  <link rel="stylesheet" href="plugins/morris/morris.css">
  <!-- jvectormap -->
  <link rel="stylesheet" href="plugins/jvectormap/jquery-jvectormap-1.2.2.css">
  <!-- Date Picker -->
  <link rel="stylesheet" href="plugins/datepicker/datepicker3.css">
  <!-- Daterange picker -->
  <link rel="stylesheet" href="plugins/daterangepicker/daterangepicker.css">
  <!-- bootstrap wysihtml5 - text editor -->
  <link rel="stylesheet" href="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">

  
  
  
  
  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
  <style type="text/css">
  #success{color:green;}
  #danger{color:red;}
  </style>
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">
    <!-- Logo -->
    <a href="index.php" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>BD</b>DEVS</span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><b>BDDEVS</b>TEAM</span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>

      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          <!-- Messages: style can be found in dropdown.less-->
		  <li><a href="../index.php" class="btn btn-primary" target="_blank"> Visit Website </a></li>
		  
          <li class="dropdown messages-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <i class="fa fa-envelope-o"></i>
			  <?php 
			  $q=mysqli_query($con,"SELECT * FROM blog_contact");
			  $msg=mysqli_num_rows($q);
			  
			  ?>
			   <span class="label label-success"><?php echo$msg;?></span>
			    </a>
            <ul class="dropdown-menu">
              <li class="header">You have <?php echo$msg;?> messages</li>
              <li>
			   <ul class="menu">
			  <?php 
			  while($rr=mysqli_fetch_array($q))
			  {
				?>
				
				
				

                <!-- inner menu: contains the actual data -->
               
                  <li><!-- start message -->
                    <a href="viewmsg.php?view=<?php echo$rr['id'];?>">
                      <div class="pull-left">
                       
                      </div>
                      <h4>
                        <?php echo$rr['name'];?>
                        <small><i class="fa fa-clock-o"></i><?php 
						echo$sending_time=date('d F,Y g:sa',strtotime($rr['date']));
						//echo$now=$sending_time-time('m');
						?> </small>
                      </h4>
                      <p><?php echo substr($rr['message'],0,30);?></p>
                    </a>
                  </li>
				  
				  <?php				
			  }
			  ?>
                  <!-- end message -->
                  
                </ul>
              </li>
              <li class="footer"><a href="viewmsg.php">See All Messages</a></li>
            </ul>
          </li>
          <!-- Notifications: style can be found in dropdown.less -->
          <li class="dropdown notifications-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <i class="fa fa-bell-o"></i>
			   <?php 
			  $s_q=mysqli_query($con,"SELECT * FROM blog_subscriber");
			  $notify=mysqli_num_rows($s_q);
			  
			  ?>
              <span class="label label-warning"><?php echo$notify;?></span>
            </a>
            <ul class="dropdown-menu">
              <li class="header">You have <?php echo$notify;?> notifications</li>
              <li>
                <!-- inner menu: contains the actual data -->
				 <?php echo$notify;?> Users Subscribed so far..
                <ul class="menu">
				<?php 
				while($s_result=mysqli_fetch_array($s_q))
				{
					?>
					
                  <li>
                    <a href="subscriber.php">
                      <i class="fa fa-users text-aqua"></i>
							<?php echo$s_result['email'];?>
							
                    </a>
                  </li><br />
				  <?php
				}
				?>
                  
                </ul>
              </li>
              <li class="footer"><a href="subscriber.php">View all</a></li>
            </ul>
          </li>
          <!-- Tasks: style can be found in dropdown.less -->
          
          <!-- User Account: style can be found in dropdown.less -->
          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <img src="dist/img/admin.jpg" class="user-image" alt="User Image">
              <span class="hidden-xs">Md. Akmal Hossain</span>
            </a>
            <ul class="dropdown-menu">
              <!-- User image -->
              <li class="user-header">
                <img src="dist/img/admin.jpg" class="img-circle" alt="User Image">

                <p>
                  Md. Akmal Hossain- Web & Software Developer
                  <small>Member since February 2016</small>
                </p>
              </li>
              <!-- Menu Body -->
              <li class="user-body">
                <div class="row">
				<div class="col-xs-4"></div>
                  <div class="col-xs-4 text-center">
                  <a href="change_admin_pass.php" class="btn btn-default">Change Password</a>
                  </div>
                 <div class="col-xs-4"></div>
                </div>
                <!-- /.row -->
              </li>
              <!-- Menu Footer-->
              <li class="user-footer">
                <div class="pull-left">
                  <a href="#" class="btn btn-default btn-flat">Profile</a>
                </div>
				
                <div class="pull-right">
                  <a href="?logout" class="btn btn-default btn-flat">Sign out</a>
				  <?php 
				  if(isset($_GET['logout']))
				  {
					  session_unset(); 
					// destroy the session 
					session_destroy();
					
				echo"<script>window.location='index.php';</script>";
				  }
				  ?>
                </div>
              </li>
            </ul>
          </li>
          <!-- Control Sidebar Toggle Button -->
         
        </ul>
      </div>
    </nav>
  </header>
  
  