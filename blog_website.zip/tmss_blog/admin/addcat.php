 
<?php include("inc/header.php");?>
<?php include("inc/sidebar.php");?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    

    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      <div class="row">
        
      </div>
      <!-- /.row -->
      <!-- Main row -->
	 <div class="col-md-3"></div>
	 <div class="col-md-6">
	 <h1> Add New Category</h1><br />
	 <?php 
	 
	 
		if(isset($_POST['submit']))
		{
			// Function for filtering input values.
			function test_input($data)
			{
			$data = trim($data);//Removes whitespaces from both sides
			$data = addslashes($data);// Add backslashes to the predefined characters in a string
			$data = htmlspecialchars($data);//The htmlspecialchars() function converts some predefined characters to HTML entities.
			return $data;
			}
			
			
			$cat_name=test_input($_POST['cat_name']);
			$cat_name=filter_var($_POST['cat_name'], FILTER_SANITIZE_STRING);//sanitizes the input using filter
	
		if($cat_name=="" || $cat_name==null)
		{
			echo"<h2 id='danger'>Plz Give a category Name</h2>";
		}
		else
		{
			
		$q=mysqli_query($con,"INSERT INTO blog_category (cat_name) VALUES ('$cat_name')");
		
			if($q)
			{
			echo"<h2 id='success'>Category $cat_name inserted Successfully!</h2>";
					//echo"<script>window.location='change_admin_pass.php';</script>";
			}
			else
			{
					echo"<h2 id='danger'>Category $cat_name not inserted!</h2>";
			}	
		}
		
			
		
		}
		
		?>
		<form action="" method="post">
			<div class="form-group">
			<label for="catname">Category Name</label>
			<input type="text" class="form-control" id="first_name" name="cat_name">
			</div>
			<button type="submit" name="submit"class="btn btn-success">Add Category</button>
		</form>
	  </div>
	  <div class="col-md-3"></div>
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	
      <!-- /.row (main row) -->

    </section>
    <!-- /.content -->
  </div>
  
  
  <?php 
  include("inc/footer.php");
  ?>