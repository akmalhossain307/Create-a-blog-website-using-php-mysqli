 
<?php include("inc/header.php");?>
<?php include("inc/sidebar.php");?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    

    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      <div class="row">
        
      </div>
      <!-- /.row -->
      <!-- Main row -->
	 
	  <div class="row"> 
		<div class="col-md-3"></div>
		<div class="col-md-6">
		<h2>Change Admin password</h2>
		<?php 
		if(isset($_POST['submit']))
		{
			
		$old=$_POST['oldpass'];
		$new=$_POST['newpass'];
		$q=mysqli_query($con,"SELECT * FROM blog_admin WHERE id=1");
		while($result=mysqli_fetch_array($q))
		{
			if($result['password']==$old)
			{
				$query=mysqli_query($con,"UPDATE blog_admin SET 
				password='$new'
				WHERE 
				id=1
				");
				if($query)
				{
					echo"<h2 id='success'>Password Changed Successfully!</h2>";
					//echo"<script>window.location='change_admin_pass.php';</script>";
				}
				else
				{
					echo"<h2 id='danger'>Something went wrong!</h2>";
				}
			}
			else
			{
				echo"<h2 id='danger'>Old Password not Matched! Try again</h2>";
			}
		}
		
		}
		
		?>
		
			<form action="" method="post">
				<div class="form-group has-feedback">
				Old Password
					<input type="password" name="oldpass"class="form-control" placeholder="Enter old password">
					
				</div>
				<div class="form-group has-feedback">
				New Password
					<input type="password" name="newpass"class="form-control" placeholder="Enter new password">
					
				</div>
				
					<button type="submit" name="submit"class="btn btn-primary btn-block btn-flat">Change Password</button>
				
      
				
			</form>
		
		</div>
		<div class="col-md-3"></div>
	  </div>
	  
	 

	
      <!-- /.row (main row) -->

    </section>
    <!-- /.content -->
  </div>
  
  
  <?php 
  include("inc/footer.php");
  ?>