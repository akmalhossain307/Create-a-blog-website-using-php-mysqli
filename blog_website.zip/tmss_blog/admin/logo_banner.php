 
<?php include("inc/header.php");?>
<?php include("inc/sidebar.php");?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    

    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      <div class="row">
        
      </div>
      <!-- /.row -->
      <!-- Main row -->
	 <div class="col-md-1"></div>
	 <div class="col-md-10">
	 <h1> Change website's Logo and Banner</h1><br />
		<?php 
	 if(isset($_POST['submit']))
	 {
		//$title		=$_POST['title']; 
		$logo		=$_FILES['logo']['name']; 
		$tmp_logo	=$_FILES['logo']['tmp_name'];
		move_uploaded_file($tmp_logo,"upload/".$logo);
		$banner		=$_FILES['banner']['name']; 
		$tmp_banner	=$_FILES['banner']['tmp_name'];
		move_uploaded_file($tmp_banner,"upload/".$banner);
		if($logo=="" && $banner=="")
		{
			echo"<script>alert('Plz select logo or banner or both!')</script>";
			echo"<script>window.location='logo_banner.php'</script>";
			
			
		}
		else if($logo=="")
		{
			
			$u_query=mysqli_query($con,"UPDATE blog_logo SET banner='$banner' WHERE id=1");
			
			if($u_query)
			{
				echo"<script>alert('banner Updated Successfully!')</script>";
				echo"<script>window.location='logo_banner.php'</script>";
			}
			else
			{
				echo"<script>alert('banner not Updated!')</script>";
				echo"<script>window.location='logo_banner.php'</script>";
			}
		}
		else if($banner=="" )
		{
			
			$u_query=mysqli_query($con,"UPDATE blog_logo SET logo='$logo' WHERE id=1");
			
			if($u_query)
			{
				echo"<script>alert('Logo Updated Successfully!')</script>";
				echo"<script>window.location='logo_banner.php'</script>";
			}
			else
			{
				echo"<script>alert('Logo not Updated!')</script>";
				echo"<script>window.location='logo_banner.php'</script>";
			}	
			
				
			
		}
		else 
		{
			
			$u_query=mysqli_query($con,"UPDATE blog_logo SET 
			logo		='$logo',
			banner		='$banner'
			WHERE id=1");
			//$ins_q=mysqli_query($con,"INSERT INTO blog_title (title,icon) VALUES('$title','$icon')");
			if($u_query)
			{
				echo"<script>alert('Logo and Banner Updated Successfully!')</script>";
				echo"<script>window.location='logo_banner.php'</script>";
			}
			else
			{
				echo"<script>alert('Logo and Banner not Updated!')</script>";
				echo"<script>window.location='logo_banner.php'</script>";
			}
		}
		 
	 }
	 ?>
	 
	 
		<form action=""method="post"enctype="multipart/form-data">
		<?php 
		$logo_query=mysqli_query($con,"SELECT * FROM blog_logo");
		while($info=mysqli_fetch_array($logo_query))
		{
			?>
		<div class="row"> 
		<div class="col-md-5">
			<div class="form-group">
			<label for="logo">Logo</label>
			<input type="file" name="logo">
			</div>
			<br />
			<br />
			<div class="form-group">
			<label for="banner">Banner</label>
			<input type="file" name="banner">
			</div>
			<button type="submit" name="submit"class="btn btn-success">Change Info</button>
		</div>
		<div class="col-md-5">
		<h2>Logo:</h2> <p><img src="upload/<?php echo$info['logo'];?>" alt="" width="80" height="80"/></p>	<br />
		<h2>Banner:</h2> <p><img src="upload/<?php echo$info['banner'];?>" alt="" width="200" height="150"/></p>	<br />
		</div>
	
		</div>	
		</form>
	  </div>
	  <div class="col-md-1"></div>
	  	
			<?php 
		}
		?>
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	
      <!-- /.row (main row) -->

    </section>
    <!-- /.content -->
  </div>
  
  
  <?php 
  include("inc/footer.php");
  ?>